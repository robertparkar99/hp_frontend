// 'use client';

// import React from 'react';

// const SkillDetailsPanel = ({ selectedSkill }) => {
//   if (!selectedSkill) return null;

//   return (
//     <div className="bg-card border border-border rounded-lg h-full overflow-hidden">
//       {/* Intentionally empty: no UI */}
//     </div>
//   );
// };

// export default SkillDetailsPanel;
