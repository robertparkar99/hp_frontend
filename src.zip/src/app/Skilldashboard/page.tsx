// src/app/skillDashboard/page.tsx
"use client";

import React from "react";
import SkillDashboard from "@/app/content/Libraries/SkillDashboard";

export default function SkilldashboardPage() {
  return <SkillDashboard />;
}
