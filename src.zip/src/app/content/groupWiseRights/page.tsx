'use client';

import React from 'react';
import { RightsManagement } from './create/RightsManagement';

export default function GroupWiseRightsPage() {
  return (
    <>
      <RightsManagement/>
    </>
  );
}