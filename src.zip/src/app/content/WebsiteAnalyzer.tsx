import React from 'react';
const WebsiteAnalyzer = () => (
    <iframe
        src="https://website-analyzer-delta.vercel.app/"
        style={{ width: '100%', height: '80vh', border: 'none' }}
        title="Website Analyzer"
    />
);
export default WebsiteAnalyzer;
