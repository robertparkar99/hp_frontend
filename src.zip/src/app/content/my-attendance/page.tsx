"use client";
import React from "react";
import { AttendanceDashboard } from "./attendance/AttendanceDashboard";


const App: React.FC = () => {
  return (
    <>
       <AttendanceDashboard />
    </>
  );
};

export default App;