import { Dashboard } from "../../Telent-management/Interview-management/component/Dashboard";

const Index = () => {
  return <Dashboard />;
};

export default Index;