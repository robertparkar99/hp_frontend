"use client";
import {Dashboard} from "@/app/content/organization-dashboard/dashboard/Dashboard";
export default function HomePage() {
  return (
    <>
      <Dashboard />
    </>
  );
}
