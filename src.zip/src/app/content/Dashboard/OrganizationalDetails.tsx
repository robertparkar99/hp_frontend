// Example content of addOrgDetails.tsx
const OrganizationalDetails = () => {
return <div className="text-black">Welcome to OrganizationalDetails</div>;
};
  
  export default OrganizationalDetails;