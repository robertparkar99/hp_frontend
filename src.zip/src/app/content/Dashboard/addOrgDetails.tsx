import React from "react";
import OrganizationProfile from "../organization-profile-management";

const AddOrgDetails: React.FC = () => {
  return (
    <>
      <OrganizationProfile />
    </>
  );
};

export default AddOrgDetails;
