import React from 'react';
const Index = () => (
    <iframe
        src="https://skill-ontology-neo4j.vercel.app/"
        style={{ width: '100%', height: '500%', border: 'none' }}
        title="Skill Neo4j"
    />
);
export default Index;